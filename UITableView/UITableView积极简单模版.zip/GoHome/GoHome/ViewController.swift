//
//  ViewController.swift
//  GoHome
//
//  Created by mike on 15/5/2017.
//  Copyright © 2017 mike. All rights reserved.
//

import UIKit
import SnapKit
import MJRefresh

class ViewController: UIViewController {
    
    fileprivate var tableView: UITableView!
    let cellIdentifier = "cellIdentifier"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        addTalbeView()
        observeAppBkTime()
    }
    
    //进入后台超过一段时间回来刷新界面
    func observeAppBkTime() -> Void {
        
        //监听程序即将进入前台运行、进入后台休眠 事件
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.applicationWillEnterForeground), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.applicationDidEnterBackground), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
        
    }
    
    static var lastLeaveTime = Date()
    func applicationWillEnterForeground(){
        //计算上次离开的时间与当前时间差
        //如果超过2分钟，则自动刷新本页面。
        let interval = -1 * ViewController.lastLeaveTime.timeIntervalSinceNow
        if interval > 120 {
            self.tableView.mj_header.beginRefreshing()
        }
    }
    func applicationDidEnterBackground(){
        ViewController.lastLeaveTime = Date()
    }

    
    func addTalbeView() -> Void {
        self.tableView = UITableView();
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.none;
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellIdentifier)
        tableView.backgroundColor = UIColor.red
        tableView.separatorColor = UIColor.white
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.view.addSubview(self.tableView)
        
        self.tableView.snp.makeConstraints{ (make) -> Void in
            make.top.right.bottom.left.equalTo(self.view);
        }
        //-------------
        self.tableView.mj_header = V2RefreshHeader(refreshingBlock: {[weak self] () -> Void in
            self?.refresh()
        })
        
        //执行一次
        refresh()
        //------------------
        
        let footer = V2RefreshFooter(refreshingBlock: {[weak self] () -> Void in
            self?.getNextPage()
        })
        footer?.centerOffset = -4
        self.tableView.mj_footer = footer

    }


   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

//load data
extension ViewController {
    
    func refreshPage(){
        self.tableView.mj_header.beginRefreshing();
        
    }
    
    func refresh(){
        
        //如果有上拉加载更多 正在执行，则取消它
        if self.tableView.mj_footer.isRefreshing() {
            self.tableView.mj_footer.endRefreshing()
        }
        
        //request ..
        
        self.tableView.reloadData()
        self.tableView.mj_header.endRefreshing()
        
        
    }
    
    func getNextPage(){
        //        if let count = self.topicList?.count , count <= 0{
        //            self.tableView.mj_footer.endRefreshing()
        //            return;
        //        }
        //....
        
        self.tableView.reloadData()
        self.tableView.mj_footer.endRefreshing()
        //根据 tab name 获取帖子列表
        //        self.currentPage += 1
        
    }
    

}

extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1;
    }

    
}

extension ViewController:UITableViewDelegate {
    
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        return 44
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath);
        cell.textLabel?.text = "aaaa"
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }

}


